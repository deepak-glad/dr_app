import 'dart:convert';

import 'package:drkashikajain/HomeScreen.dart';
import 'package:drkashikajain/login/LoginScreen.dart';
import 'package:drkashikajain/app_colors.dart';
import 'package:drkashikajain/primary_button.dart';
import 'package:drkashikajain/selectlanguageScreen.dart';
import 'package:drkashikajain/utils/constants.dart';
import 'package:drkashikajain/utils/method.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'RaisedGradientButton.dart';
import 'custom_view/route_animations.dart';
import 'custom_view/utils.dart';

class RegistrationScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return RegistrationScreenState();
  }
}

class RegistrationScreenState extends State<RegistrationScreen> {
  bool internet = true;
  bool _isLoaded = false;

  var _nameTextController;
  var _emailTextController;
  var _cityTextController;
  var _passwordTextController;
  var _mobileTextController;
  static final RegExp _emailRegex =
      RegExp(r'^[a-zA-Z0-9.]+@[a-zA-Z0-9]+\.[a-zA-Z]+');

  @override
  void initState() {
    super.initState();
    _nameTextController = TextEditingController();
    _emailTextController = TextEditingController();
    _cityTextController = TextEditingController();
    _passwordTextController = TextEditingController();
    _mobileTextController = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage("images/back.png"),
              fit: BoxFit.cover,
            ),
          ),
          child: Center(
            child: Form(
              child: ListView(
                shrinkWrap: true,
                physics: const AlwaysScrollableScrollPhysics(),
                children: <Widget>[
                  !_isLoaded
                      ? _loginWidgeta()
                      : Center(
                          child: Center(child: CircularProgressIndicator()),
                        ),
                ],
              ),
            ),
          ),
        ),
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          // backgroundColor: AppColors.primary_color,
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: Text(
            'Registration Form',
            style: TextStyle(
              fontSize: 16.0,
              fontWeight: FontWeight.bold,
            ),
          ),
          centerTitle: true,
        ));
  }

  _loginWidgeta() {
    return new Column(
      children: <Widget>[
        new Container(
          margin: EdgeInsets.only(top: 30),
          height: 100.0,
          width: 100.0,
          child: Image.asset("images/logo.png"),
        ),
        new Container(
          margin: EdgeInsets.only(top: 20.0, left: 20.0, right: 20.0),
          child: TextFormField(
            controller: _nameTextController,
            style: TextStyle(color: Colors.black),
            decoration: new InputDecoration(
              contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.white, width: 2.0),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.white, width: 2.0),
              ),
              fillColor: Colors.white,
              filled: true,
              hintStyle: TextStyle(color: Colors.black),
              hintText: 'Name',
            ),
          ),
        ),
        new Container(
          margin: EdgeInsets.only(top: 20.0, left: 20.0, right: 20.0),
          child: TextFormField(
            controller: _emailTextController,
            keyboardType: TextInputType.emailAddress,
            decoration: new InputDecoration(
              contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.white, width: 2.0),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.white, width: 2.0),
              ),
              fillColor: Colors.white,
              filled: true,
              hintStyle: TextStyle(color: Colors.black),
              hintText: 'Email Id',
            ),
          ),
        ),
        new Container(
          margin: EdgeInsets.only(top: 20.0, left: 20.0, right: 20.0),
          child: TextFormField(
            controller: _passwordTextController,
            obscureText: true,
            keyboardType: TextInputType.visiblePassword,
            decoration: new InputDecoration(
              contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.white, width: 2.0),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.white, width: 2.0),
              ),
              fillColor: Colors.white,
              filled: true,
              hintStyle: TextStyle(color: Colors.black),
              hintText: 'Create Password',
            ),
          ),
        ),
        new Container(
          margin: EdgeInsets.only(top: 20.0, left: 20.0, right: 20.0),
          child: TextFormField(
            controller: _mobileTextController,
            keyboardType: TextInputType.number,
            maxLength: 10,
            decoration: new InputDecoration(
              contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.white, width: 2.0),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.white, width: 2.0),
              ),
              fillColor: Colors.white,
              filled: true,
              hintStyle: TextStyle(color: Colors.black),
              hintText: 'Mobile Number',
            ),
          ),
        ),
        new Container(
          margin: EdgeInsets.symmetric(horizontal: 20.0),
          child: TextFormField(
            controller: _cityTextController,
            decoration: new InputDecoration(
              contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.white, width: 2.0),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.white, width: 2.0),
              ),
              fillColor: Colors.white,
              filled: true,
              hintStyle: TextStyle(color: Colors.black),
              hintText: 'City Name',
            ),
          ),
        ),
        continueButton()
      ],
    );
  }

  Widget continueButton() {
    return Container(
      child: Padding(
        padding: EdgeInsets.only(bottom: 50, left: 30, right: 30, top: 30),
        child: PrimaryButton(
            buttonText: 'Submit', onButtonPressed: () => _loginButtonTapped()),
      ),
    );
  }

  BoxDecoration myBoxDecoration() {
    return BoxDecoration(
      borderRadius: BorderRadius.all(Radius.circular(10)),
      border: Border.all(color: Colors.white),
    );
  }

  _loginButtonTapped() {
    if (_nameTextController.text.toString().isEmpty) {
      Utils.showErrorMessage(context, 'Enter your name');
      return;
    } else if (_mobileTextController.text.isEmpty) {
      Utils.showErrorMessage(context, 'Enter  mobile number');
      return;
    } else if (!isValidEmail(_emailTextController.text.toString())) {
      Utils.showErrorMessage(context, 'Enter valid email Id');
      return;
    } else if (_passwordTextController.text.toString().isEmpty) {
      Utils.showErrorMessage(context, 'Enter Password');
      return;
    } else if (_cityTextController.text.toString().isEmpty) {
      Utils.showErrorMessage(context, 'Enter City');
      return;
    } else {
      apihit();
    }
  }

  static bool isValidEmail(String email) {
    return _emailRegex.hasMatch(email);
  }

  Future<void> apihit() async {
    internet = await Method.check();
    setState(() {
      _isLoaded = true;
    });
    print("email_or_phone>>>>>>>>>>>" + _emailTextController.text.toString());
    print("password>>>>>>>>>>>" + _passwordTextController.text.toString());
    print("full_name>>>>>>>>>>>" + _nameTextController.text.toString());

    Map<String, String> body = {
      'first_name': _nameTextController.text.toString(),
      'last_name': "",
      'user_email': _emailTextController.text.toString(),
      'user_password': _passwordTextController.text.toString(),
      'user_phone': _mobileTextController.text.toString(),
      'city_id': _cityTextController.text.toString(),
      'device_token': "63765167yu",
      'device_type': "android",
    };
    if (internet != null && internet) {
      try {
        final response = await http
            .post(KApiBase.BASE_URL + KApiEndPoints.API_SIGN_UP, body: body);
        Map mapRes = json.decode(response.body.toString());
        print("responseBody>>>>>>>>>>>" + mapRes.toString());

        if (response.statusCode == 200) {
          if (mapRes['code'] == "200") {
            setState(() {
              loginAPI();
            });
            // Utils.showErrorMessage(context, mapRes['message']);
          } else {
            setState(() {
              _isLoaded = false;
            });
            Utils.showErrorMessage(context, mapRes['message']);
          }
        } else {
          throw Exception('Unable to fetch products from the REST API');
        }
      } catch (e) {
        print("Exception rest api: " + e);
      }
    }
  }

  Future<void> loginAPI() async {
    internet = await Method.check();
    setState(() {
      _isLoaded = true;
    });
    print("email_or_phone>>>>>>>>>>>" + _emailTextController.text.toString());
    print("password>>>>>>>>>>>" + _passwordTextController.text.toString());
    print("full_name>>>>>>>>>>>" + _nameTextController.text.toString());

    Map<String, String> body = {
      'user_email': _emailTextController.text.toString(),
      'password': _passwordTextController.text.toString(),
      'device_token': "63765167yu",
      'device_type': "android",
      'device_name': "PPP",
      'device_id': "android_id",
    };
    if (internet != null && internet) {
      try {
        final response = await http
            .post(KApiBase.BASE_URL + KApiEndPoints.API_LOGIN, body: body);
        Map mapRes = json.decode(response.body.toString());
        print("responseBody>>>>>>>>>>>" + mapRes.toString());

        if (response.statusCode == 200) {
          if (mapRes['code'] == "200") {
            setState(() {
              _isLoaded = false;
            });

            Utils.showErrorMessage(context, mapRes['message']);
            SharedPreferences prefs = await SharedPreferences.getInstance();
            prefs.setString(KPrefs.USER_ID,
                mapRes['user_details'][0]['user_id'].toString());
            prefs.setString(
                KPrefs.TOKEN, mapRes['user_details'][0]["access_token"]);
            prefs.setString(
                KPrefs.USER_NAME, mapRes['user_details'][0]["username"]);
            prefs.setString(
                KPrefs.USER_EMAIL, mapRes['user_details'][0]["user_email"]);
            prefs.setString(
                KPrefs.MOBILE, mapRes['user_details'][0]["user_phone"]);
            await prefs.setString("type", "login");
            Navigator.pushAndRemoveUntil(
                context,
                RouteAnimationSlideFromRight(
                    widget: SelectLanguageScreen(), routeName: ""),
                (Route<dynamic> route) => false);
          } else {
            setState(() {
              _isLoaded = false;
            });
            Utils.showErrorMessage(context, mapRes['message']);
          }
        } else {
          throw Exception('Unable to fetch products from the REST API');
        }
      } catch (e) {
        print("Exception rest api: " + e);
      }
    }
  }
}
