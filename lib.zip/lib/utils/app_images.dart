class AppAssets {
  static String splashBackground = 'assets/images/Splash_logo.png';
  static String appLogo = 'assets/images/logo.jpeg';
  static String appLogotrans = 'assets/images/logo_trans.png';
  static String onBoardingFirst = 'assets/images/walk1.png';
  static String onBoardingSecond = 'assets/images/walk2.png';
  static String onBoardingThird = 'assets/images/walk3.png';
  static String KEy = 'assets/images/slider2.png';
}
