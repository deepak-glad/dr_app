class AppString {
  static String submit = 'submit';
  static String login = 'Login';
  static String signUp = 'Signup';
  static String alreadyAccount = 'Already have an account?';
  static String signUpAccount = 'Don\'t have an account?';
}
